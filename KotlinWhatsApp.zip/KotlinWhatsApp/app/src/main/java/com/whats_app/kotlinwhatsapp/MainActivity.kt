package com.whats_app.kotlinwhatsapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    // variables
    private var mAuth: FirebaseAuth? = null
    private var currentUser: FirebaseUser? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initFirebase()
        signIn()
    }

    private fun signIn() {
        mAuth!!.signInWithEmailAndPassword("omar.alaa4@yahoo.com", "123456")
            .addOnCompleteListener { task: Task<AuthResult> ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Sign in success ...", Toast.LENGTH_LONG).show()
                } // sign in was success
                else {
                    Toast.makeText(this, "Sign in fail ...", Toast.LENGTH_LONG).show()

                } // sign in fail
            }
    } // sign in

    private fun initFirebase() {
        FirebaseApp.initializeApp(applicationContext);

        mAuth = FirebaseAuth.getInstance()

    } // get instance from firebase

    override fun onStart() {

        super.onStart()
        currentUser = mAuth!!.currentUser
        if (currentUser != null) {
            Toast.makeText(this, "User is logged in ...", Toast.LENGTH_LONG).show()
        } else
            Toast.makeText(this, "User is logged out ...", Toast.LENGTH_LONG).show()


    } // get current user
}
